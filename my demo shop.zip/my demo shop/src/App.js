
import Mainpagetitle from './components/Mainpagetitle';
import Product from './components/Product';

function App() {
  const products=[
    {id:1,
    title:'Product 1',
    price:'10',
    description:'First product',
    }
    ,
    {id:2,
      title:'Product 2',
      price:'20',
      description:'Second product',
      },
  ]
  return (
    <div className="App">
      <Mainpagetitle></Mainpagetitle>
      <Product title={products[0].title} price={products[0].price} description={products[0].description}/>
      <Product title={products[1].title} price={products[1].price} description={products[1].description}/>
    </div>
  );
}

export default App;
