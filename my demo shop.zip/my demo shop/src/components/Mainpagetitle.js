import './Mainpagetitle.css'

function Mainpagetitle () {
    return(
        <div className="title-name">
            <h1>My Demo Shop</h1>
        </div>
    );
}
export default Mainpagetitle;