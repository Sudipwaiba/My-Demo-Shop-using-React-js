import './Product.css';


function Product (props) {

    // const title="Product 1";
    // const price="$10";
    // const description="First Product"
    return (
        <div className='product-item'>
            <div className='product-item_title'>
                <h1>{props.title}</h1>
            </div>
            <div className='product-item_price'>
                <h1>{props.price}</h1>
            </div>
            <div className='product-item_description'>
                <h1>{props.description}</h1>
            </div>
        </div>
    );
}

export default Product;